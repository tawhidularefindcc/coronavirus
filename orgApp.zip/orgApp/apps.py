from django.apps import AppConfig


class OrgappConfig(AppConfig):
    name = 'orgApp'
