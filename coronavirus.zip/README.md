# coronavirus
I hope this project bring the necessary need what we need to solve corona virus problem.

#This is how you download it in your repo

https://coronavirus-1.gitbook.io/general-knowledge/undefined-4/undefined/undefined

This is the full documentation of our Project :
https://coronavirus-1.gitbook.io/general-knowledge/

#This is our bata apps:
https://coronavirus-stagibg.herokuapp.com/

#This is our live apps :
https://coronavirusbd.herokuapp.com/

# How to Run This project in your local machin :

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/93Kyxdic8rI/0.jpg)](https://www.youtube.com/watch?v=93Kyxdic8rI)

# Our Contact From Fiture :

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/4gCj9mV6yRc/0.jpg)](https://www.youtube.com/watch?v=4gCj9mV6yRc)

# Our Ci/Cd Process to maintain that Application :

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/Uxhu11SNA2U/0.jpg)](https://www.youtube.com/watch?v=Uxhu11SNA2U)



Asaduzzaman Sohel
gitrepo:  https://github.com/asadlive84/coronavirus
Deployed App: https://coronovirus19.herokuapp.com/coruna/










