from django.apps import AppConfig


class CorunaappConfig(AppConfig):
    name = 'corunaApp'
